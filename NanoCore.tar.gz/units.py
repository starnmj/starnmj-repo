from math import pi
ang2bohr = 1.889726878  # Angstrom to bohr conversion
rad2deg = 180/pi # degree to radian conversion
degrad = 1./rad2deg
