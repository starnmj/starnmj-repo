#
# SIESTA
#

siesta_calculator = '~/mybin/siesta_class'
siesta_psf_location = '/home2/jhiskard/mybin/psf'
siesta_util_location = '~/mybin'
siesta_util_band = 'new.gnubands'
siesta_util_dos  = 'Eig2DOS'
siesta_util_pdos = 'fmpdos'
siesta_util_rho  = 'rho2xsf'
siesta_util_vh   = 'macroave'
